import sys
import os

# Get filename from command-line argument
if len(sys.argv) != 2:
    print('Usage: python wordCount.py <filename>')
    sys.exit(1)
filename = sys.argv[1]

# Check if file exists and is readable
if not os.path.isfile(filename):
    print(f'Error: {filename} does not exist.')
    sys.exit(1)
if not os.access(filename, os.R_OK):
    print(f'Error: {filename} is not readable.')
    sys.exit(1)

# Read words from file and count them
count = 0
with open(filename, 'r') as f:
    for line in f:
        count += len(line.strip().split())

# Check if file is empty
if count == 0:
    print(f'Error: {filename} is empty.')
    sys.exit(1)

# Print word count
print(count)
