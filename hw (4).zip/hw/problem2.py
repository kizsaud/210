import sys

# Get filename from command-line argument
if len(sys.argv) != 2:
    print('Usage: python wordSort.py <filename>')
    sys.exit(1)

filename = sys.argv[1]

try:
    # Read words from file
    words = []
    with open(filename, 'r') as f:
        for line in f:
            for word in line.strip().split():
                words.append(word)

    # Sort words case-insensitively
    words_sorted = sorted(words, key=str.lower)

    # Print sorted words
    for word in words_sorted:
        print(word)

except FileNotFoundError:
    print(f"Error: File '{filename}' not found")
    sys.exit(1)

except Exception as e:
    print(f"An error occurred: {e}")
    sys.exit(1)
