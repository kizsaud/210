import sys

# Check for correct number of command-line arguments
if len(sys.argv) != 2:
    print('Usage: python wordCountDistinct.py <filename>')
    sys.exit(1)

filename = sys.argv[1]

try:
    with open(filename, 'r') as f:
        # Read words from file, convert to lowercase, and count distinct words
        distinct_words = set()
        for line in f:
            words = line.strip().split()
            for word in words:
                distinct_words.add(word.lower())

        # Print number of distinct words
        print(f"Number of distinct words in file '{filename}': {len(distinct_words)}")
except FileNotFoundError:
    print(f"Error: file '{filename}' not found.")
    sys.exit(1)
except PermissionError:
    print(f"Error: permission denied to access file '{filename}'.")
    sys.exit(1)
