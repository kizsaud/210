import numpy as np
import sys

# Read file and create numpy array
try:
    filename = sys.argv[1]
except IndexError:
    filename = 'roster2.dat'

try:
    data = np.genfromtxt(filename, delimiter=',', dtype={'names': ('name', 'age', 'major', 'gpa'), 'formats': ('U50', 'i4', 'U4', 'f8')})
except OSError:
    print(f"Error: Could not open file {filename}")
    sys.exit(1)

# Compute and print average GPA of all students
avg_gpa_all = np.mean(data['gpa'])
print(f"Average GPA of all students: {avg_gpa_all:.3f}")

# Compute and print maximum GPA of CS majors
cs_data = data[data['major'] == 'CS']
if len(cs_data) == 0:
    max_gpa_cs = 0
else:
    max_gpa_cs = np.max(cs_data['gpa'])
print(f"Maximum GPA of CS majors: {max_gpa_cs:.3f}")

# Compute and print number of students with GPA over 3.5
num_high_gpa = np.sum(data['gpa'] > 3.5)
print(f"Number of students with GPA over 3.5: {num_high_gpa}")

# Compute and print average GPA of students at least 25 years old
older_data = data[data['age'] >= 25]
if len(older_data) == 0:
    avg_gpa_over25 = 0
else:
    avg_gpa_over25 = np.mean(older_data['gpa'])
print(f"Average GPA of students at least 25 years old: {avg_gpa_over25:.3f}")

# Compute and print major with highest average GPA among students at most 22 years old
max_gpa_major = ''
max_gpa = 0.0
for major in np.unique(data['major']):
    younger_data = data[(data['major'] == major) & (data['age'] <= 22)]
    if len(younger_data) == 0:
        continue
    avg_gpa = np.mean(younger_data['gpa'])
    if avg_gpa > max_gpa:
        max_gpa = avg_gpa
        max_gpa_major = major
if max_gpa_major == '':
    max_gpa_major = 'None'
print(f"Major with highest average GPA among students at most 22 years old: {max_gpa_major}")
