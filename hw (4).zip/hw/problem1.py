import sys
import collections

# Get filename from command-line argument or use default file
if len(sys.argv) > 2:
    print('Usage: python rosterStats.py [<filename>]')
    sys.exit(1)
elif len(sys.argv) == 2:
    filename = sys.argv[1]
else:
    filename = 'roster1.dat'

# Read data from input file
data = []
try:
    with open(filename, 'r') as f:
        for line in f:
            fields = line.strip().split(',')
            if len(fields) == 4:
                name, major, gpa, credits = fields
                data.append((name, major, float(gpa), int(credits)))
except FileNotFoundError:
    print(f"Error: File {filename} not found.")
    sys.exit(1)
except ValueError:
    print(f"Error: File {filename} contains invalid data.")
    sys.exit(1)

# Compute summary statistics by major
major_stats = collections.defaultdict(lambda: {'total_gpa': 0, 'total_credits': 0, 'count': 0})
for _, major, gpa, credits in data:
    major_stats[major]['total_gpa'] += gpa
    major_stats[major]['total_credits'] += credits
    major_stats[major]['count'] += 1

# Write summary statistics to output file
try:
    with open('roster1.out', 'w') as f:
        f.write('major,avgGpa,avgCredits,count\n')
        for major in sorted(major_stats.keys()):
            count = major_stats[major]['count']
            if count > 0:
                avg_gpa = major_stats[major]['total_gpa'] / count
                avg_credits = major_stats[major]['total_credits'] / count
                f.write(f'{major},{avg_gpa:.2f},{avg_credits:.2f},{count}\n')
except PermissionError:
    print("Error: Could not write to output file roster1.out.")
    sys.exit(1)
