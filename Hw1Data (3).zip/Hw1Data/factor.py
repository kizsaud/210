#Khizar Saud, Hw 1, Problem 2
# factor.py: Factor an integer n given as a command-line argument (assume n ≥ 2). 
import sys

def main(n):
    """Factor an integer n"""
    factors = []
    for i in range(2, n + 1):
        while n % i == 0:
            factors.append(i)
            n = n // i
    return factors

if __name__ == "__main__":
    n = int(sys.argv[1])
    print(main(n))
    