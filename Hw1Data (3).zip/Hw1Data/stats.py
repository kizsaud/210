import sys
import statistics as stats

def main():
    """Reads a list of integers from the user and prints the mean, median, and standard deviation of the list"""
    numbers = []
    while True:
        number = int(input("Enter a number (-12345 to stop): "))
        if number == -12345:
            break
        numbers.append(number)
    
    mean = stats.mean(numbers)
    median = stats.median(numbers)
    stdev = stats.stdev(numbers) if len(numbers) > 1 else 0
    
    print("mean: {:.2f}".format(mean))
    print("median: {:.2f}".format(median))
    print("standard deviation: {:.2f}".format(stdev))

if __name__ == "__main__":
    main()
