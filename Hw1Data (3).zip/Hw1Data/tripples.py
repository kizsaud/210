#Khizar Saud
#Hw 1 Problem 5
import sys

def main():
    numbers = []
    num = int(input("Enter a number (or -12345 to stop): "))
    while num != -12345:
        numbers.append(num)
        num = int(input("Enter a number (or -12345 to stop): "))

    triples = find_zero_triples(numbers)
    if len(triples) == 0:
        print("0 triples found")
    else:
        print(f"{len(triples)} triples found:")
        for triple in triples:
            print(triple)

def find_zero_triples(numbers):
    triples = []
    for i in range(len(numbers)):
        for j in range(i+1, len(numbers)):
            for k in range(j+1, len(numbers)):
                if numbers[i] + numbers[j] + numbers[k] == 0:
                    triples.append((numbers[i], numbers[j], numbers[k]))
    return triples

if __name__ == "__main__":
    sys.exit(main())