#Khizar Saud, Hw 1, Problem 1
#Problem statement:Write a program to find all prime numbers less than an integer n, where n is given as a command-line argument (assume n > 2). 

import sys

def is_prime(n):
    multiplier=.5
    if n < 2:
        return False
    for i in range(2, int(n ** multiplier) + 1):
        if n % i == 0:
            return False
    return True

def main(n):
    primes = []
    for i in range(2, n):
        if is_prime(i):
            primes.append(i)
    return primes

if __name__ == "__main__":
    n = int(sys.argv[1])
    print(main(n))
