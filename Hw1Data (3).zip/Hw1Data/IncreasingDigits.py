#Khizar Saud, Hw 1, Problem 2
#3. increasingDigits.py: Write a program to count all integers from 1 to n (inclusive) that have all digits in increasing order, where n is given as a command-line argument.
import sys

import sys

def main(n):
    """Count all integers less than n that have all digits in increasing order"""
    count = 0
    for i in range(1, n):
        str_i = str(i)
        increasing = True
        for j in range(1, len(str_i)):
            if int(str_i[j - 1]) >= int(str_i[j]):
                increasing = False
                break
        if increasing:
            count += 1
    return count

if __name__ == "__main__":
    n = int(sys.argv[1])
    print(main(n))
